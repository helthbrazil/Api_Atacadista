package br.com.hebert.springboot_docker;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import br.com.hebert.entity.Confirmacao;
import br.com.hebert.entity.Log;
import br.com.hebert.entity.Orcamento;
import br.com.hebert.entity.RespostaOrcamento;
import br.com.hebert.entity.StatusResposta;
import br.com.hebert.entity.TesteApi;
import br.com.hebert.entity.UrlPadrao;
import br.com.hebert.service.HTTPUtil;
import io.swagger.annotations.ApiOperation;

/**
 * Hello world!
 *
 */
@SpringBootApplication
@RestController
@RequestMapping("/orcamento")
public class App {
	private UrlPadrao urlPadrao = new UrlPadrao("http://localhost", "5000");

	public App() {

	}

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}

	// Teste atacadista

	@ApiOperation(value = "Url de Teste ")
	@RequestMapping(value = "/testeSolicitacaoAtacadista", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody RespostaOrcamento testeSolicitacaoAtacadista(@RequestBody Orcamento orcamento) {
		// Vai chamar a url do serviço do atacadista e retornar o id p numero do
		// orcamento data entrega e valor

		RespostaOrcamento resposta = new RespostaOrcamento();
		resposta.setValor(450.40);
		resposta.setNumOrcamento(5);
		resposta.setDtEntrega("2017-07-22");

		return resposta;
	}

	// Teste atacadista
	@ApiOperation(value = "Url de Teste")
	@RequestMapping(value = "/testeAtacadistaReceberConfirmacao", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody StatusResposta testeAtacadistaReceberConfirmacao(@RequestBody Confirmacao confirmacao) {

		StatusResposta status = new StatusResposta();
		status.setNumOrcamento(confirmacao.getNumOrcamento());
		status.setStatus("Produzindo");
		return status;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	private String prepareUrl() {
		return this.urlPadrao.getUrl() + ":" + this.urlPadrao.getPorta() + "/";
	}

	@ApiOperation(value = "Solicita um orçamento de um pedido")
	@RequestMapping(value = "/solicitar", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody RespostaOrcamento solicitarOrcamento(@RequestBody Orcamento orcamento) {
		// Vai chamar a url do serviço do atacadista e retornar o id p numero do
		// orcamento data entrega e valor
		String urlAtacadista = this.prepareUrl() + "api/mart/Orcamento";
		System.out.println("Url requisitada: " + urlAtacadista);

		String resposta = "";

		HTTPUtil httpUtil = new HTTPUtil();
		try {
			resposta = httpUtil.executePost(urlAtacadista, orcamento);
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Gson gson = new Gson();
		return gson.fromJson(resposta, RespostaOrcamento.class);
	}

	@ApiOperation(value = "Url para atualizar o estado do pedido")
	@RequestMapping(value = "/statusPedido", method = RequestMethod.PUT, produces = "application/json")
	public @ResponseBody StatusResposta statusPedido(@RequestBody StatusResposta status) {
		// Vai ser chamado pelo atacadista para ser informado do status do
		// pedido

		HTTPUtil httpUtil = new HTTPUtil();
		String response = "";
		try {
			response = httpUtil.sendGet("");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Status do pedido atualizado");
		System.out.println();
		Gson gson = new Gson();

		return status;
	}

	@ApiOperation(value = "Envio de confirmação de orçamento")
	@RequestMapping(value = "/enviarResposta", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody StatusResposta enviarResposta(@RequestBody Confirmacao confirmacao) {
		// Enviar a resposta para o atacadista e receber o status do pedido

		String urlAtacadista = this.prepareUrl() + "api/mart/pedido";
		System.out.println("Url requisitada: " + urlAtacadista);
		String resposta = "";

		HTTPUtil httpUtil = new HTTPUtil();
		try {
			resposta = httpUtil.executePut(urlAtacadista, confirmacao);
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Gson gson = new Gson();
		return gson.fromJson(resposta, StatusResposta.class);
	}

	@ApiOperation(value = "Recebe as atualizações por parte do atacadista")
	@RequestMapping(value = "/atualizarStatusOrcamento", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody Log atualizarStatusOrcamento(@RequestBody StatusResposta status) {
		// Enviar a resposta para o atacadista e receber o status do pedido

		Log log = new Log();
		log.setLogMessage("Status do orçamento: " + status.getNumOrcamento() + " atualizado com sucesso.");
		return log;
	}

	@ApiOperation(value = "Teste de funcionamento do serviço")
	@RequestMapping(value = "/teste", method = RequestMethod.GET, produces = "application/json")
	public TesteApi teste() {
		TesteApi teste = new TesteApi();
		HTTPUtil httpUtil = new HTTPUtil();

		// httpUtil.sendGet(this.prepareUrl() + "orcamento/testeRequisicao");
		teste.setStatus(200);
		teste.setResposta("O serviço está funcionando normalmente");

		return teste;
	}

	@ApiOperation(value = "Consulta url e porta do serviço do atacadista")
	@RequestMapping(value = "/consultarUrlEPorta", method = RequestMethod.GET, produces = "application/json")
	public UrlPadrao consultarUrlEPorta() {
		return this.urlPadrao;
	}
	
	
/*
	@RequestMapping(value = "/testeRequisicao", method = RequestMethod.GET, produces = "application/json")
	private String testeRequisicao() {
		return "Recurso interno";
	}*/

	/*
	@RequestMapping(value = "/modificarUrlEPorta", method = RequestMethod.POST, produces = "application/json")
	public UrlPadrao modificarUrlEPorta(@RequestBody UrlPadrao url) {

		try {
			this.urlPadrao = url;

		} catch (Exception e) {
			urlPadrao.setUrl("http://localhost");
			urlPadrao.setPorta("8080");
		}
		this.urlPadrao = urlPadrao;
		System.out.println("Url alterada para " + prepareUrl());

		return urlPadrao;
	}*/

}
