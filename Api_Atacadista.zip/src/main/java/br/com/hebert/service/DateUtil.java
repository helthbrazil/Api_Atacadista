package br.com.hebert.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateUtil {
	public static String CalendarToString() {
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		sdf.format(calendar.getTime());

		return sdf.format(calendar.getTime());
	}
}
