package br.com.hebert.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClientBuilder;

import com.google.gson.Gson;

import interfaces.IPojo;

public class HTTPUtil {

	private final String USER_AGENT = "Mozilla/5.0";

	// HTTP GET request
	public String sendGet(String url) throws Exception {

		String url2 = "https://viacep.com.br/ws/32223080/json/";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");

		// add request header
		con.setRequestProperty("User-Agent", USER_AGENT);

		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'GET' request to URL : " + url);
		System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// print result
		return response.toString();

	}

	public static String executePost(String targetURL, IPojo pojo) throws ClientProtocolException, IOException {

		Gson gson = new Gson();
		HttpClient httpClient = HttpClientBuilder.create().build();
		HttpPost post = new HttpPost(targetURL);
		StringEntity postingString = new StringEntity(gson.toJson(pojo));
		post.setEntity(postingString);
		post.setHeader("Content-type", "application/json");
		HttpResponse response = httpClient.execute(post);
		String responseString = new BasicResponseHandler().handleResponse(response);
		System.out.println(responseString);

		return responseString;
	}

	public static String executePut(String targetURL, IPojo pojo) throws ClientProtocolException, IOException {

		Gson gson = new Gson();
		HttpClient httpClient = HttpClientBuilder.create().build();
		HttpPut put = new HttpPut(targetURL);
		StringEntity postingString = new StringEntity(gson.toJson(pojo));
		put.setEntity(postingString);
		put.setHeader("Content-type", "application/json");
		HttpResponse response = httpClient.execute(put);
		String responseString = new BasicResponseHandler().handleResponse(response);
		System.out.println(responseString);

		return responseString;
	}
}
