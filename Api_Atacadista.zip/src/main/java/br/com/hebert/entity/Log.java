package br.com.hebert.entity;

import java.util.Calendar;

import br.com.hebert.service.DateUtil;

public class Log {
	private String logMessage;
	private String data;

	public Log() {
		this.data = DateUtil.CalendarToString();
	}

	public String getLogMessage() {
		return logMessage;
	}

	public void setLogMessage(String logMessage) {
		this.logMessage = logMessage;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

}
