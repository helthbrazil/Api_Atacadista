package br.com.hebert.entity;

import interfaces.IPojo;

public class RespostaOrcamento implements IPojo {
	private Integer numOrcamento;
	private String dtEntrega;
	private Double valor;

	public RespostaOrcamento() {

	}

	public Integer getNumOrcamento() {
		return numOrcamento;
	}

	public void setNumOrcamento(Integer numOrcamento) {
		this.numOrcamento = numOrcamento;
	}

	public String getDtEntrega() {
		return dtEntrega;
	}

	public void setDtEntrega(String dtEntrega) {
		this.dtEntrega = dtEntrega;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

}
