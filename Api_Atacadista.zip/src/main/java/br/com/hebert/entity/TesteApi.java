package br.com.hebert.entity;

import interfaces.IPojo;

public class TesteApi implements IPojo {
	private String resposta;
	private Integer status;

	public TesteApi() {
		// TODO Auto-generated constructor stub
	}

	public String getResposta() {
		return resposta;
	}

	public void setResposta(String resposta) {
		this.resposta = resposta;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}
