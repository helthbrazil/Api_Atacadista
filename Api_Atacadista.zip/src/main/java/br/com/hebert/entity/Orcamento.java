package br.com.hebert.entity;

import interfaces.IPojo;

public class Orcamento implements IPojo {
	private Integer codProduto;
	private Integer qtdItens;
	private String observacao;

	public Orcamento() {

	}

	@Override
	public String toString() {
		return "codProduto:" + codProduto + "\r\n" + "qtdItens:" + qtdItens + "\r\n" + "observacao:" + observacao;
	}

	public Integer getCodProduto() {
		return codProduto;
	}

	public void setCodProduto(Integer codProduto) {
		this.codProduto = codProduto;
	}

	public Integer getQtdItens() {
		return qtdItens;
	}

	public void setQtdItens(Integer qtdItens) {
		this.qtdItens = qtdItens;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

}
