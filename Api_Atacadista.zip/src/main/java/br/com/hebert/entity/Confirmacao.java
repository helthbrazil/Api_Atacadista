package br.com.hebert.entity;

import interfaces.IPojo;

public class Confirmacao implements IPojo {
	private Integer numOrcamento;
	private boolean confirmacao;

	public Confirmacao() {

	}

	public Integer getNumOrcamento() {
		return numOrcamento;
	}

	public void setNumOrcamento(Integer numOrcamento) {
		this.numOrcamento = numOrcamento;
	}

	public boolean isConfirmacao() {
		return confirmacao;
	}

	public void setConfirmacao(boolean confirmacao) {
		this.confirmacao = confirmacao;
	}

}
