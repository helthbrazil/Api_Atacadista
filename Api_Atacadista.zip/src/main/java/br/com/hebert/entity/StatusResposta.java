package br.com.hebert.entity;

import interfaces.IPojo;

public class StatusResposta implements IPojo {
	private Integer numOrcamento;
	private String status;

	public StatusResposta() {

	}

	public Integer getNumOrcamento() {
		return numOrcamento;
	}

	public void setNumOrcamento(Integer numOrcamento) {
		this.numOrcamento = numOrcamento;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
