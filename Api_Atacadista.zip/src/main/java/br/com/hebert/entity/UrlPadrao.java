package br.com.hebert.entity;

public class UrlPadrao {
	private String url;
	private String porta;

	public UrlPadrao() {
		// TODO Auto-generated constructor stub
	}
	

	public UrlPadrao(String url, String porta) {
		super();
		this.url = url;
		this.porta = porta;
	}


	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getPorta() {
		return porta;
	}

	public void setPorta(String porta) {
		this.porta = porta;
	}

}
