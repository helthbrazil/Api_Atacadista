package interfaces;

public interface IPojo {
	
}
